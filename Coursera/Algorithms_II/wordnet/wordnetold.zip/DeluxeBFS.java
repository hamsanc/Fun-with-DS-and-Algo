/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.ST;

public class DeluxeBFS {
    private static final int INFINITY = Integer.MAX_VALUE;
    private static final int VER_V = 1;
    private static final int VER_W = 2;
    //Symbol table instead of array
    ST<Integer,Integer> marked = new ST<Integer,Integer>();
    ST<Integer,Integer> edgeTo = new ST<Integer,Integer>();
    ST<Integer,Integer> distTo = new ST<Integer,Integer>();


    private int commonanestor;
    private int sl;
    private int graphsize;

    public DeluxeBFS(Digraph G, Iterable<Integer> v, Iterable<Integer> w) {

        graphsize = G.V();

        validateVertices(v);
        validateVertices(w);

        bfs(G, v, w);
    }

    // BFS from multiple sources
    private void bfs(Digraph G, Iterable<Integer> v, Iterable<Integer> w) {
        Queue<Integer> qv = new Queue<Integer>();
        Queue<Integer> qw = new Queue<Integer>();

        // Initialise commonanestor and shortest length
        commonanestor = -1;
        sl =  -1;

        // initialise and enque V
        for (int s : v) {
            marked.put(s,VER_V);
            distTo.put(s,0);
            qv.enqueue(s);
        }

        // initialise and enque w
        for (int s : w) {

           if(marked.contains(s)){
                commonanestor = s;
                sl =  0;
                return;
            }
            marked.put(s,VER_W);
            distTo.put(s,0);
            qw.enqueue(s);
        }

        while (true) {

            //System.out.println("Elements in the queue v  " + qv);
            //System.out.println("Elements in the queue w  " + qw);

            if (!qv.isEmpty()) {
                int vv = qv.dequeue();

                //System.out.println("Dequeued element v " + vv);
                //System.out.print("Adjacent elements ");

                for (int ad : G.adj(vv)) {
                    //System.out.print(ad + " ");
                    if (!marked.contains(ad)) {
                        edgeTo.put(ad,vv);
                        distTo.put(ad,distTo.get(vv)+1);
                        marked.put(ad,VER_V);

                        //System.out.println("Distance " + distTo.get(ad) + " ");

                        if(sl != -1 && distTo.get(ad) > sl) break;
                        qv.enqueue(ad);
                    }
                    else {
                        //System.out.println();
                        //System.out.println(marked.get(ad)+" "+distTo.get(ad)+" "+(distTo.get(vv)+1));

                        if (marked.get(ad) == 2) {

                            if (commonanestor == -1) {

                                //System.out.println("found something common first time in VV");

                                commonanestor = ad;
                                sl = distTo.get(ad) + distTo.get(vv) + 1;

                                //System.out.println("CA " + commonanestor);
                                //System.out.println("SL " + sl);
                            }
                            else {
                                //System.out.println("found something again in VV");

                                int len = distTo.get(ad) + distTo.get(vv) + 1;


                                //System.out.println(distTo.get(ad) + " " + distTo.get(vv) + " " + len);

                                if (len < sl) {
                                    commonanestor = ad;
                                    sl = len;

                                    //System.out.println("CA " + commonanestor);
                                    //System.out.println("SL " + sl);
                                }

                            }
                        }


                        int k = distTo.get(vv) + 1;
                        if(k <= distTo.get(ad) ){
                            //System.out.println("VVVVV");
                            edgeTo.put(ad,vv);
                            distTo.put(ad,distTo.get(vv)+1);
                            marked.put(ad,VER_V);
                            qv.enqueue(ad);
                            //System.out.println(marked.get(ad)+" "+distTo.get(ad));
                        }
                    }
                }

            }

            if (!qw.isEmpty()) {
                int ww = qw.dequeue();

                //System.out.println("Dequeued element ww " + ww);
                //System.out.print("Adjacent elements ");

                for (int ad : G.adj(ww)) {
                    //System.out.print(ad + " ");
                    if (!marked.contains(ad)) {
                        edgeTo.put(ad,ww);
                        distTo.put(ad,distTo.get(ww)+1);
                        marked.put(ad,VER_W);

                        //System.out.println("Distance " + distTo.get(ad) + " ");

                        if(sl != -1 && distTo.get(ad) > sl) break;
                        qw.enqueue(ad);
                    }
                    else {
                        //System.out.println();
                        //System.out.println(marked.get(ad)+" "+distTo.get(ad)+" "+(distTo.get(ww)+1));

                        if (marked.get(ad) == 1) {

                            if (commonanestor == -1) {

                                //System.out.println("found something common first time in WW");

                                commonanestor = ad;
                                sl = distTo.get(ad) + distTo.get(ww) + 1;

                                //System.out.println("CA " + commonanestor);
                                //System.out.println("SL " + sl);
                            }
                            else {
                                //System.out.println("found something again in WW");

                                int len = distTo.get(ad) + distTo.get(ww) + 1;

                                //System.out.println(distTo.get(ad) + " " + distTo.get(ww) + " " + len);

                                if (len < sl) {
                                    commonanestor = ad;
                                    sl = len;

                                   //System.out.println("CA " + commonanestor);
                                   //System.out.println("SL " + sl);
                                }

                            }
                        }

                        int k = distTo.get(ww) + 1;
                        if(k <= distTo.get(ad) ){
                            //System.out.println("WWWWWWW");
                            edgeTo.put(ad,ww);
                            distTo.put(ad,distTo.get(ww)+1);
                            marked.put(ad,VER_W);
                            qw.enqueue(ad);
                            //System.out.println(marked.get(ad)+" "+distTo.get(ad));
                        }
                    }
                }
            }

            //System.out.println();

            if(qv.isEmpty() && qw.isEmpty()) break;
        }
    }

    public int distTo(int v) {
        validateVertex(v);
        return distTo.get(v);
    }


    public int Commonanestor() {

        return commonanestor;
    }

    public int shortestlength() {

        return sl;
    }


    // throw an IllegalArgumentException unless {@code 0 <= v < V}
    private void validateVertex(int v) {
        int V = graphsize;
        if (v < 0 || v >= V)
            throw new IllegalArgumentException("vertex " + v + " is not between 0 and " + (V - 1));
    }

    // throw an IllegalArgumentException unless {@code 0 <= v < V}
    private void validateVertices(Iterable<Integer> vertices) {
        if (vertices == null) {
            throw new IllegalArgumentException("argument is null");
        }
        for (Integer v : vertices) {
            if (v == null) {
                throw new IllegalArgumentException("vertex is null");
            }
            validateVertex(v);
        }
    }


    public static void main(String[] args) {

    }
}

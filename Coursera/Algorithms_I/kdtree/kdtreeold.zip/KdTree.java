/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.RectHV;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;


public class KdTree {

    private Node root;             // root of KdTree
    private int size;

    private class Node {

        private Point2D p;      // the point
        private RectHV rect;    // the axis-aligned rectangle corresponding to this node
        private Node left, right;    // left and right subtrees
        private int orientation;      // 0 = vertical 1 = horizontal

        public Node(Point2D p, int orient, double xmin, double ymin, double xmax, double ymax) {
            this.p = p;
            this.orientation = orient;
            this.rect = new RectHV(xmin, ymin, xmax, ymax);
        }

    }


    // construct an empty set of points
    public KdTree() {

    }

    // is the set empty?
    public boolean isEmpty() {
        return size == 0;
    }

    // number of points in the set
    public int size() {
        return size;
    }


    // add the point to the set (if it is not already in the set)
    public void insert(Point2D p) {
        if (p == null)
            throw new IllegalArgumentException("Parameter passed to insert is null");
       // System.out.println(p+"      Start");
        if(root == null) {
            root = new Node(p, 0, 0.0, 0.0, 1.0, 1.0);
            size++;
        }else {
            if (!contains(p)) {
                Queue<Node> queue = new Queue<Node>();
                queue.enqueue(root);
                int orient = 0;
                int cmp = 0;
                int count = 0;
                while(!queue.isEmpty()){
                    Node x = queue.dequeue();
                    if (orient == 0) {
                        cmp = Point2D.X_ORDER.compare(p, x.p);
                        count++;
                        orient = 1;
                    }
                    else {
                        cmp = Point2D.Y_ORDER.compare(p, x.p);
                        count++;
                        orient = 0;
                    }
                    if (orient == 0) {
                        if (cmp < 0) {
                            if (x.left == null) {
                                x.left = new Node(p, orient, x.rect.xmin(), x.rect.ymin(), x.rect.xmax(),
                                                  x.p.y());
                                break;
                            }
                            else {
                                //x.left = insert(x.left, p, orient, x.rect.xmin(), x.rect.ymin(), x.rect.xmax(),
                                  //              x.p.y(), count);
                                queue.enqueue(x.left);
                            }
                        }
                        else {
                            if (x.right == null) {
                                x.right = new Node(p, orient, x.rect.xmin(), x.p.y(), x.rect.xmax(),
                                                   x.rect.ymax());
                                break;
                            }
                            else {
                               // x.right = insert(x.right, p, orient, x.rect.xmin(), x.p.y(), x.rect.xmax(),
                               //                  x.rect.ymax(), count);
                                queue.enqueue(x.right);
                            }
                        }
                    }
                    else {
                        if (cmp < 0) {
                            if(x.left == null){
                                x.left = new Node(p, orient,x.rect.xmin(), x.rect.ymin(), x.p.x(),
                                                  x.rect.ymax());
                                break;
                            } else {
                               // x.left = insert(x.left, p, orient, x.rect.xmin(), x.rect.ymin(), x.p.x(),
                                 //               x.rect.ymax(),count);
                                queue.enqueue(x.left);
                            }
                        }
                        else {
                            if(x.right == null){
                                x.right = new Node(p,orient,x.p.x(), x.rect.ymin(), x.rect.xmax(),
                                                   x.rect.ymax());
                                break;
                            } else {
                                //x.right = insert(x.right, p, orient, x.p.x(), x.rect.ymin(), x.rect.xmax(),
                                  //               x.rect.ymax(),count);
                                queue.enqueue(x.right);
                            }
                        }

                    }

                }
                size++;
               // System.out.println(count);
            }

        }


    }

  /*  private Node insert(Node x, Point2D p, int ore, double xmin, double ymin, double xmax,
                        double ymax,int cnt) {
       if (x == null) return new Node(p, ore, xmin, ymin, xmax, ymax);
        System.out.println(cnt);
        int orient = ore;
        int cmp = 0;
        int count = cnt;
        if (ore == 0) {
            cmp = Point2D.X_ORDER.compare(p, x.p);
            count++;
            orient = 1;

        }
        else {
            cmp = Point2D.Y_ORDER.compare(p, x.p);
            count++;
            orient = 0;
        }

        if (orient == 0) {
            if (cmp < 0) {
                if (x.left == null) {
                    x.left = new Node(p, orient, x.rect.xmin(), x.rect.ymin(), x.rect.xmax(),
                                      x.p.y());
                    return x;
                }
                else {
                    x.left = insert(x.left, p, orient, x.rect.xmin(), x.rect.ymin(), x.rect.xmax(),
                                    x.p.y(), count);
                }
            }
            else {
                if (x.right == null) {
                    x.right = new Node(p, orient, x.rect.xmin(), x.p.y(), x.rect.xmax(),
                                       x.rect.ymax());
                    return x;
                }
                else {
                    x.right = insert(x.right, p, orient, x.rect.xmin(), x.p.y(), x.rect.xmax(),
                                     x.rect.ymax(), count);
                }
            }
        }
        else {
            if (cmp < 0) {
                if(x.left == null){
                    x.left = new Node(p, orient,x.rect.xmin(), x.rect.ymin(), x.p.x(),
                                      x.rect.ymax());
                    return x;
                } else {
                    x.left = insert(x.left, p, orient, x.rect.xmin(), x.rect.ymin(), x.p.x(),
                                    x.rect.ymax(),count);
                }
            }
            else {
                if(x.right == null){
                    x.right = new Node(p,orient,x.p.x(), x.rect.ymin(), x.rect.xmax(),
                                       x.rect.ymax());
                    return x;
                } else {
                    x.right = insert(x.right, p, orient, x.p.x(), x.rect.ymin(), x.rect.xmax(),
                                     x.rect.ymax(),count);
                }
            }

        }

        return x;
    }*/

    // does the set contain point p?
    public boolean contains(Point2D p) {
        if (p == null) throw new IllegalArgumentException("argument to contains() is null");
        boolean con = false;
        for (Node nd : this.levelOrder()) {
            if (p.equals(nd.p)) {
                con = true;
                break;
            }
        }
        return con;
    }


    private Iterable<Node> levelOrder() {
        Queue<Node> nd = new Queue<Node>();
        Queue<Node> queue = new Queue<Node>();
        queue.enqueue(root);
        while (!queue.isEmpty()) {
            Node x = queue.dequeue();
            if (x == null) continue;
            nd.enqueue(x);
            queue.enqueue(x.left);
            queue.enqueue(x.right);
        }
        return nd;
    }

    // draw all points to standard draw
    public void draw() {
        StdDraw.clear();
        boolean first = true;

        for (Node nd : this.levelOrder()) {
            StdDraw.setPenRadius(0.01);
            StdDraw.setPenColor(StdDraw.BLACK);
            StdDraw.point(nd.p.x(), nd.p.y());
            StdDraw.setPenRadius(0.005);
            if (nd.orientation == 0) {
                StdDraw.setPenColor(StdDraw.RED);
                StdDraw.line(nd.p.x(), nd.rect.ymin(), nd.p.x(), nd.rect.ymax());
            }
            else {
                StdDraw.setPenColor(StdDraw.BLUE);
                StdDraw.line(nd.rect.xmin(), nd.p.y(), nd.rect.xmax(), nd.p.y());
            }

        }
    }

    // all points that are inside the rectangle (or on the boundary)
    public Iterable<Point2D> range(RectHV rect) {
        Queue<Point2D> pt = new Queue<Point2D>();
        Queue<Node> queue = new Queue<Node>();
        queue.enqueue(root);
        while (!queue.isEmpty()) {
            Node x = queue.dequeue();
            if (x == null) continue;
            if (rect.intersects(x.rect)) {
                if (rect.contains(x.p)) {
                    pt.enqueue(x.p);
                }
                queue.enqueue(x.left);
                queue.enqueue(x.right);
            }

        }
        return pt;
    }


    // a nearest neighbor in the set to point p; null if the set is empty
    public Point2D nearest(Point2D p) {
        Point2D champ_pt = root.p;
        double champ_r = root.p.distanceSquaredTo(p);

        Stack<Node> st = new Stack<Node>();
        st.push(root);
        while (!st.isEmpty()) {
            Node x = st.pop();
            if (x == null) continue;

            if (x.rect.distanceSquaredTo(p) > champ_r) {

                continue;
            }

            double leftdist = Double.POSITIVE_INFINITY;
            double rightdist = Double.POSITIVE_INFINITY;
            if (x.left != null) {
                leftdist = x.left.p.distanceSquaredTo(p);

            }
            if (x.right != null) {
                rightdist = x.right.p.distanceSquaredTo(p);
            }


            if (leftdist <= rightdist) {
                if (leftdist < champ_r) {
                    champ_r = leftdist;
                    champ_pt = x.left.p;
                }
                st.push(x.right);
                st.push(x.left);
            }
            else {
                if (rightdist < champ_r) {
                    champ_r = rightdist;
                    champ_pt = x.right.p;
                }
                st.push(x.left);
                st.push(x.right);
            }

        }
        return champ_pt;
    }


    public static void main(String[] args) {


        String filename = args[0];
        In in = new In(filename);
        KdTree kdtree = new KdTree();
        while (!in.isEmpty()) {
            double x = in.readDouble();
            double y = in.readDouble();
            Point2D p = new Point2D(x, y);
            kdtree.insert(p);
            StdOut.printf("%8.6f %8.6f\n", x, y);
        }

        for (Node nd : kdtree.levelOrder()) {
            System.out.println(nd.p + " " + nd.orientation);
            System.out.println(nd.rect.xmin() + " " + nd.rect.ymin());
            System.out.println(nd.rect.xmax() + " " + nd.rect.ymax());
        }

        kdtree.draw();
        StdDraw.show();

    }
}

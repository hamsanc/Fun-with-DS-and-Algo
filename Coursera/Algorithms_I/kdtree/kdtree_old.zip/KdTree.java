/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.RectHV;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdDraw;


public class KdTree {

    private Node root;             // root of KdTree
    private int size;

    private class Node {

        private Point2D p;      // the point
        private RectHV rect;    // the axis-aligned rectangle corresponding to this node
        private Node left, right;    // left and right subtrees
        private int orientation;      // 0 = vertical 1 = horizontal

        public Node(Point2D p, int orient, double xmin, double ymin, double xmax, double ymax) {
            this.p = p;
            this.orientation = orient;
            this.rect = new RectHV(xmin, ymin, xmax, ymax);
        }

    }


    // construct an empty set of points
    public KdTree() {

    }

    // is the set empty?
    public boolean isEmpty() {
        return size == 0;
    }

    // number of points in the set
    public int size() {
        return size;
    }


    // add the point to the set (if it is not already in the set)
    public void insert(Point2D p) {
        if (p == null)
            throw new IllegalArgumentException("Parameter passed to insert is null");
        if (!contains(p)) {
            root = put(root,p,0,0.0,0.0,1.0,1.0);
            size++;
        }
    }

    private Node put(Node x, Point2D p, int orient, double xmin, double ymin, double xmax,
                     double ymax) {
        if (x == null) return new Node(p,orient,xmin,ymin,xmax,ymax);
        if(orient == 0){
            int cmpx = Point2D.X_ORDER.compare(p, x.p);
            if(cmpx < 0) x.left = put(x.left, p, 1, x.rect.xmin(), x.rect.ymin(), x.p.x(),
                                      x.rect.ymax());
            else x.right = put(x.right, p, 1, x.p.x(), x.rect.ymin(), x.rect.xmax(),
                               x.rect.ymax());

        }else {
            int cmpy = Point2D.Y_ORDER.compare(p, x.p);
            if(cmpy < 0)x.left = put(x.left, p, 0, x.rect.xmin(), x.rect.ymin(), x.rect.xmax(),
                                     x.p.y());
            else x.right = put(x.right, p, 0, x.rect.xmin(), x.p.y(), x.rect.xmax(),
                               x.rect.ymax());
        }

        return x;
    }

    // does the set contain point p?
    public boolean contains(Point2D p) {
        if (p == null) throw new IllegalArgumentException("argument to contains() is null");
        return get(root, p, 0) != null;
    }

    private Point2D get(Node x, Point2D p, int orient) {
        if (x == null) return null;
        if (orient == 0) {
            int cmpx = Point2D.X_ORDER.compare(p, x.p);
            if (cmpx < 0) return get(x.left, p, 1);
            else if (cmpx > 0) return get(x.right, p, 1);
            else {
                if (x.p.equals(p)) return x.p;
                return get(x.right, p, 1);
            }
        }
        else {
            int cmpy = Point2D.Y_ORDER.compare(p, x.p);
            if (cmpy < 0) return get(x.left, p, 0);
            else if (cmpy > 0) return get(x.right, p, 0);
            else {
                if (x.p.equals(p)) return x.p;
                return get(x.right, p, 0);
            }
        }

    }


    private Iterable<Node> levelOrder() {
        Queue<Node> nd = new Queue<Node>();
        Queue<Node> queue = new Queue<Node>();
        queue.enqueue(root);
        while (!queue.isEmpty()) {
            Node x = queue.dequeue();
            if (x == null) continue;
            nd.enqueue(x);
            queue.enqueue(x.left);
            queue.enqueue(x.right);
        }
        return nd;
    }

    // draw all points to standard draw
    public void draw() {
        StdDraw.clear();
        boolean first = true;

        for (Node nd : this.levelOrder()) {
            StdDraw.setPenRadius(0.01);
            StdDraw.setPenColor(StdDraw.BLACK);
            StdDraw.point(nd.p.x(), nd.p.y());
            StdDraw.setPenRadius(0.005);
            if (nd.orientation == 0) {
                StdDraw.setPenColor(StdDraw.RED);
                StdDraw.line(nd.p.x(), nd.rect.ymin(), nd.p.x(), nd.rect.ymax());
            }
            else {
                StdDraw.setPenColor(StdDraw.BLUE);
                StdDraw.line(nd.rect.xmin(), nd.p.y(), nd.rect.xmax(), nd.p.y());
            }

        }
    }

    // all points that are inside the rectangle (or on the boundary)
    public Iterable<Point2D> range(RectHV rect) {
        Queue<Point2D> pt = new Queue<Point2D>();
        Queue<Node> queue = new Queue<Node>();
        queue.enqueue(root);
        while (!queue.isEmpty()) {
            Node x = queue.dequeue();
            if (x == null) continue;
            if (rect.intersects(x.rect)) {
                if (rect.contains(x.p)) {
                    pt.enqueue(x.p);
                }
                queue.enqueue(x.left);
                queue.enqueue(x.right);
            }

        }
        return pt;
    }


    // a nearest neighbor in the set to point p; null if the set is empty
    public Point2D nearest(Point2D p) {
        Point2D champ_pt = root.p;
        double champ_r = root.p.distanceSquaredTo(p);

        Stack<Node> st = new Stack<Node>();
        st.push(root);
        while (!st.isEmpty()) {
            Node x = st.pop();
            if (x == null) continue;

            if (x.rect.distanceSquaredTo(p) > champ_r) {

                continue;
            }

            double leftdist = Double.POSITIVE_INFINITY;
            double rightdist = Double.POSITIVE_INFINITY;
            if (x.left != null) {
                leftdist = x.left.p.distanceSquaredTo(p);

            }
            if (x.right != null) {
                rightdist = x.right.p.distanceSquaredTo(p);
            }


            if (leftdist <= rightdist) {
                if (leftdist < champ_r) {
                    champ_r = leftdist;
                    champ_pt = x.left.p;
                }
                st.push(x.right);
                st.push(x.left);
            }
            else {
                if (rightdist < champ_r) {
                    champ_r = rightdist;
                    champ_pt = x.right.p;
                }
                st.push(x.left);
                st.push(x.right);
            }

        }
        return champ_pt;
    }


    public static void main(String[] args) {


        String filename = args[0];
        In in = new In(filename);
        KdTree kdtree = new KdTree();
        while (!in.isEmpty()) {
            double x = in.readDouble();
            double y = in.readDouble();
            Point2D p = new Point2D(x, y);
            kdtree.insert(p);

        }
        kdtree.draw();
        StdDraw.show();

    }
}
